<?php $__env->startSection('content'); ?>
<!-- template -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($sub); ?> <br><br>
                    <a href="/akun/create" title="Tambah data">
                        <button type="button" class="btn btn-primary">Tambah</button>
                    </a>
                </h5>
                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered">
                        <thead>
                            <tr align="center">
                                <th>No</th>
                                <th>Kode Akun</th>
                                <th>Nama Akun</th>
                                <th>Aksi</th>
                            </tr>
                        <tbody>
                            <?php $__currentLoopData = $akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td align="center"><?php echo e($index + 1); ?></td>
                                <td> <?php echo e($row->kode_akun); ?> </td>
                                <td> <?php echo e($row->nama_akun); ?> </td>
                                <td align="center">
                                    <a href="<?php echo e(route('akun.edit', $row->id)); ?>" title="Ubah Data">
                                        <span class="btn btn-cyan btn-sm text-white"><i class="fa fa-edit"></i>Ubah</span>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('akun.destroy', $row->id)); ?>" style="display: inline-block;">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-danger btn-sm show_confirm" data-toggle="tooltip" title='Delete' data-konf-delete="<?php echo e($row->nama_akun); ?>"><i class="fa fa-trash"></i>Hapus</button></button>
                                    </form>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- template end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\teaminti\resources\views/backend/v_akun/index.blade.php ENDPATH**/ ?>