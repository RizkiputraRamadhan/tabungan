<?php $__env->startSection('content'); ?>
<!-- template -->
<?php if( auth()->user()->typeuser == 1 ): ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($sub); ?></h5>
                <div class="table-responsive">
                    Selamat datang hi, <b><?php echo e(auth()->user()->nama); ?></b> 
                    <p class="mt-2">
                         
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($sub); ?></h5>
                <div class="table-responsive">
                    Selamat datang hi, <b><?php echo e(auth()->user()->nama); ?></b> 
                    <p class="mt-2">
                       <b>Peraturan Ujian :</b>
                       <p>
                        1. Peserta tidak boleh meninggalkan ujian ketika sudah memulai ujian. <br>
                        2. Peserta memasuki ujian tepat pada waktunya. <br>
                        3. Peserta tidak boleh menengok kanan kiri atau bertanya kepada temannya. <br>
                        4. Peserta tidak boleh membuka tab baru pada browser dan membuka aplikasi lain selain halaman ujian. <br>
                        5. Jika Peserta melanggar pasal 1 dan 4 maka secara otomatis ujian <b>GAGAL/KELUAR UJIAN DENGAN SENDIRINYA.</b>. <br>
                          
                       </p>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php if($profil): ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><b>PROFIL <?php echo e(auth()->user()->nama); ?>:</b></h5>
                <div class="table-responsive">

                        <div class="card-body">
                            <div class="form-group">
                                <img src="<?php echo e(asset('storage/siswa/'.$profil->image)); ?>" class="foto-preview mb-2 rounded" style= "width: 20%;" alt="Image Preview">
                            </div>
                            <div class="form-group">
                                <p class="mt-2">
                                    <b>NAMA :</b>
                                    <input class="ml-2" disabled ="text" value="<?php echo e($profil->kelas); ?>">
                                 </p>
                                <p class="mt-2">
                                    <b>EMAIL :</b>
                                    <input class="ml-2 w-25" disabled ="text" value="<?php echo e(auth()->user()->email); ?>">
                                 </p>
                                <p class="mt-2">
                                    <b>KELAS :</b> 
                                    <input class="ml-2" disabled ="text" value="<?php echo e($profil->kelas); ?>">
                                 </p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><b>Lengkapi Profil Anda :</b></h5>
                <div class="table-responsive">
                    <form action="/siswa/profil/store" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="image">Foto background merah/biru</label>
                                <input type="file" name="image" id="image" class="form-control" onchange="previewFoto()">
                            </div>

                            <img id="imagePreview" class="foto-preview mb-2" style="display: none; width: 30%;" alt="Image Preview">

                            <div class="form-group">
                                <label>Nama Siswa</label>
                                <input disabled type="text" name="name" value="<?php echo e(auth()->user()->nama); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan Nama Lengkap">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Kelas</label>
                                <input type="text" name="kelas" value="<?php echo e(old('kelas')); ?>" class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan kelas">
                                <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                           
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>
<!-- template end-->
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\SIPENTING\resources\views/backend/v_home/index.blade.php ENDPATH**/ ?>