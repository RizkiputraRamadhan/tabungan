<?php $__env->startSection('content'); ?>
    <!-- template -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($sub); ?> <br><br>
                        <a href="/categories/create" title="Tambah data">
                            <button type="button" class="btn btn-primary">Tambah</button>
                        </a>
                    </h5>
                    <div class="table-responsive">
                        <table id="zero_config" class="table-striped table-bordered table">
                            <thead>
                                <tr align="center">
                                    <th>No</th>
                                    <th>Kategori</th>
                                    <th>Jam Mulai</th>
                                    <th>Jam Selesai</th>
                                    <th>Pelaksanaan</th>
                                    <th>Durasi</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td align="center"><?php echo e($index + 1); ?></td>
                                        <td> <?php echo e($row->name); ?> </td>
                                        <td> <?php echo e($row->jam_mulai); ?> </td>
                                        <td> <?php echo e($row->jam_selesai); ?> </td>
                                        <td> <?php echo e($row->tanggal_pelaksanaan); ?> </td>
                                        <td> <?php echo e($row->durasi); ?> </td>
                                        <td>
                                            <?php if($row->status == 1): ?>
                                                <a href="/categories/draft/<?php echo e($row->id); ?>"><span
                                                        class="badge badge-success">Publish</span></a>
                                            <?php else: ?>
                                                <a href="/categories/publish/<?php echo e($row->id); ?>"><span
                                                        class="badge badge-danger">Draft</span></a>
                                            <?php endif; ?>
                                        <td align="center">
                                            <a href="<?php echo e(url('categories/edit', $row->id)); ?>" title="Ubah Data">
                                                <span class="btn btn-cyan btn-sm m-1 text-white"><i
                                                        class="fa fa-edit"></i>Ubah</span>
                                            </a>
                                            <form method="POST" action="<?php echo e(url('categories/destroy', $row->id)); ?>"
                                                style="display: inline-block;">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="button" class="btn btn-danger btn-sm show_confirm m-1"
                                                    data-toggle="tooltip" title='Delete'
                                                    data-konf-delete="<?php echo e($row->name); ?>"><i
                                                        class="fa fa-trash"></i>Hapus</button></button>
                                            </form>
                                            <a href="<?php echo e(url('question/create', $row->id)); ?>" title="Pertanyaan">
                                                <span class="btn btn-success btn-sm m-1 text-white"><i
                                                        class="fa fa-edit"></i>Buat Pertanyaan</span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- template end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\teaminti\resources\views/backend/v_kategori/index.blade.php ENDPATH**/ ?>