<?php $__env->startSection('content'); ?>
<!-- template -->

<body>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="d-flex justify-content-between m-2">
                <div>
                    <h4 class="card-title"><?php echo e($sub); ?></h4>
                <div class="form-group">
                    <span type="text" value="<?php echo e($question->id); ?>" name="category_id" class="badge badge-success"><?php echo e($question->Categories->name); ?></span> <span type="text"  class="badge badge-info">edit soal <?php echo e($question->content); ?></span>
                </div>
                </div>
            </div>
            <form action="<?php echo e(url('question/update/' .$question->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label for="image">Question Image</label>
                        <input type="file" name="image" id="image" class="form-control" onchange="previewFoto()">
                    </div>
                    <div class="d-flex">
                        <?php if($question->image != null): ?>
                        <img width="30%" src="<?php echo e(asset('storage/question/'.$question->image)); ?>" alt="">
                        <span class="p-5">TO</span>
                        <img id="imagePreview" class="foto-preview mb-2" style="display: none; width: 30%;" alt="Image Preview">
                        <?php else: ?>
                        <img id="imagePreview" class="foto-preview mb-2" style="display: none; width: 30%;" alt="Image Preview">
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="content">Question</label>
                        <textarea name="content" id="editor" class="form-control" rows="4" placeholder="Enter the question content"><?php echo e($question->content); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback alert-danger" role="alert">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php for($i = 'A'; $i <= 'E'; $i++): ?>
                        <div class="form-group">
                            <label for="option_<?php echo e(strtolower($i)); ?>">Option <?php echo e($i); ?></label>
                            <input type="text" name="option_<?php echo e(strtolower($i)); ?>" id="option_<?php echo e(strtolower($i)); ?>" class="form-control"
                                placeholder="Option <?php echo e($i); ?>" value="<?php echo e($question->option_. strtolower($i)); ?>">
                        </div>
                    <?php endfor; ?>
                    <div class="form-group">
                        <label for="correct_option">Correct Option</label>
                        <select name="correct_option" id="correct_option" class="form-control">
                            <?php for($i = 'A'; $i <= 'E'; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($question->correct_option == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Ubah</button>
                    <a href="<?php echo e(url('question/create/'.$question->category_id)); ?>">
                        <button type="button" class="btn btn-danger">
                            Kembali
                        </button>
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>

<!-- template end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\SIPENTING\resources\views/backend/v_question/edit.blade.php ENDPATH**/ ?>