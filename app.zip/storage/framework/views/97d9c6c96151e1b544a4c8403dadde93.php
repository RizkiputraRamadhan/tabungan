<?php $__env->startSection('content'); ?>
<!-- template -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($sub); ?></h5>
                <div class="table-responsive">
                    Selamat datang hi, <b><?php echo e(auth()->user()->nama); ?></b> pada aplikasi pertama saya dilaravel
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam porro officia, similique enim temporibus blanditiis reiciendis at reprehenderit tempora repudiandae maxime ratione, debitis molestias modi minus, eligendi consequuntur incidunt praesentium?
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- template end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\teaminti\resources\views/backend/v_home/index.blade.php ENDPATH**/ ?>