<?php $__env->startSection('content'); ?>
    <!-- template -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">List Ujian Siswa</h5>
                    <div class="table-responsive">
                        Selamat datang hi, <b><?php echo e(auth()->user()->nama); ?></b> dihalaman daftar ujian.
                        <p></p>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="zero_config" class="table-striped table-bordered table">
                        <thead>
                            <tr align="center">
                                <th>No</th>
                                <th>Kategori</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
                                <th>Pelaksanaan</th>
                                <th>Durasi</th>
                                <th>Status</th>
                                <th>Benar</th>
                                <th>Salah</th>
                                <th>Jumlah Soal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $resultQuestion = $result->where('category_id', $row->id)
                                        ->where('users_id', auth()->user()->id)->first();
                                    $countQuestion = $questionCount->where('category_id', $row->id)->count();
                                    $correctCount = $resultQuestion ? $resultQuestion->true : 0;
                                    $incorrectCount = $resultQuestion ? $resultQuestion->false : 0;
                                ?>
                                <tr>
                                    <td align="center"><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->jam_mulai); ?></td>
                                    <td><?php echo e($row->jam_selesai); ?></td>
                                    <td><?php echo e($row->tanggal_pelaksanaan); ?></td>
                                    <td><?php echo e($row->durasi); ?></td>
                                    <td>
                                        <?php if($row->status == 1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Panding</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($correctCount); ?></td>
                                    <td><?php echo e($incorrectCount); ?></td>
                                    <td><?php echo e($countQuestion); ?></td>
                                    <td align="center">
                                        <?php if($row->status == 1): ?>
                                            <?php if($resultQuestion): ?>
                                                <button class="btn btn-secondary btn-sm m-1" disabled>
                                                    <i class="fa fa-edit"></i> Ujian Selesai
                                                </button>
                                            <?php else: ?>
                                                <a href="<?php echo e(url($row->token)); ?>" title="Pertanyaan">
                                                    <span class="btn btn-success btn-sm m-1 text-white">
                                                        <i class="fa fa-edit"></i> Mulai Ujian
                                                    </span>
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Panding</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- template end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\SIPENTING\resources\views/backend/v_exam/index.blade.php ENDPATH**/ ?>