<?php $__env->startSection('content'); ?>
    <!-- template -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 type="text" class="badge badge-success card-title"><?php echo e($sub); ?></h5>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 type="text" class="card-title">Akun <?php echo e($sub); ?></h5>
                            <hr>
                            <div class="ml-3">
                                <p>Nama : <?php echo e($siswa->nama); ?></p>
                                <p>Email : <?php echo e($siswa->email); ?></p>
                            </div>
                        </div>
                        <div class="card-body">
                            <h5 type="text" class="card-title">Profil <?php echo e($sub); ?></h5>
                            <hr>
                            <?php if(!$profil): ?>
                                <h5 type="text" class="badge badge-danger card-title"> belum melengkapi data</h5>
                            <?php else: ?>
                                <div class="ml-3">
                                    <div class="col-lg-3 col-md-6">
                                        <div class="card">
                                            <div class="el-card-item">
                                                <div class="el-card-avatar el-overlay-1"> <img class="rounded-lg"
                                                        width=" 200px" src="<?php echo e(asset('storage/siswa/' . $profil->image)); ?>"
                                                        alt="user" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p>Nama : <?php echo e($profil->name); ?></p>
                                    <p>Kelas : <?php echo e($profil->kelas); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <h5 type="text" class="card-title">Histori Ujian <?php echo e($sub); ?></h5>
                            <hr>
                            <?php if(!$histori): ?>
                                <h5 type="text" class="badge badge-danger card-title"> belum ada data histori ujian</h5>
                            <?php else: ?>
                                <div class="ml-3">
                                    <div class="table-responsive">
                                        <table id="zero_config" class="table-striped table-bordered table">
                                            <thead>
                                                <tr align="center">
                                                    <th>No</th>
                                                    <th>Nama</th>
                                                    <th>Email</th>
                                                    <th>Category</th>
                                                    <th>Soal Benar</th>
                                                    <th>Soal Salah</th>
                                                    <th>Jumlah Soal</th>
                                                    <th>Keterangan</th>
                                                    <th>Selesai Mengerjakan</th>
                                                </tr>
                                            <tbody>
                                                <?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td align="center"><?php echo e($index + 1); ?></td>
                                                        <td> <?php echo e($row->user->nama); ?> </td>
                                                        <td> <?php echo e($row->user->email); ?> </td>
                                                        <td class="text-success font-bold"> <?php echo e($row->category->name); ?> </td>
                                                        <td> <?php echo e($row->true); ?> </td>
                                                        <td> <?php echo e($row->false); ?> </td>
                                                        <td> <?php echo e($row->false + $row->true); ?> </td>
                                                        <td> <?php echo e($row->cheat); ?> </td>
                                                        <td> <?php echo e($row->updated_at); ?> </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- template end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\SIPENTING\resources\views/backend/v_siswa/detail.blade.php ENDPATH**/ ?>