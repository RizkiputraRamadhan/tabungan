
<?php $__env->startSection('content'); ?>
    <!-- template -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div>
                        <h4 class="badge badge-info"><?php echo e($category->name); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="ml-3">
                            <div class="table-responsive">
                                <table id="zero_config" class="table-striped table-bordered table">
                                    <thead>
                                        <tr align="center">
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Kelas</th>
                                            <th>Soal Benar</th>
                                            <th>Soal Salah</th>
                                            <th>Jumlah Soal</th>
                                            <th>Keterangan</th>
                                            <th>Selesai Mengerjakan</th>
                                            <th>Detail</th>
                                        </tr>
                                    <tbody>
                                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td align="center"><?php echo e($index + 1); ?></td>
                                                <td> <?php echo e($row->user->nama); ?> </td>
                                                <td>
                                                    <?php
                                                        $siswa = $siswa->where('users_id', $row->user->id)->first();
                                                    ?>
                                                    <?php if($siswa): ?>
                                                        <?php echo e($siswa->kelas); ?>

                                                    <?php else: ?>
                                                        Profil belum lengkap
                                                    <?php endif; ?>
                                                </td>
                                                <td> <?php echo e($row->true); ?> </td>
                                                <td> <?php echo e($row->false); ?> </td>
                                                <td> <?php echo e($row->false + $row->true); ?> </td>
                                                <td> <?php echo e($row->cheat); ?> </td>
                                                <td> <?php echo e($row->updated_at); ?> </td>
                                                <td><a href="/siswa/detail/<?php echo e($row->user->id); ?>"><span
                                                            class="btn btn-cyan btn-sm m-1 text-white">Detail</span></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- template end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\SIPENTING\resources\views/backend/v_result/detail.blade.php ENDPATH**/ ?>