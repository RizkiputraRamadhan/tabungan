<?php $__env->startSection('content'); ?>
    <!-- template -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="zero_config" class="table-striped table-bordered table">
                            <thead>
                                <tr align="center">
                                    <th>No</th>
                                    <th>Pelajaran</th>
                                    <th>Pelaksanaan</th>
                                    <th>Durasi</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align="center"><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->tanggal_pelaksanaan); ?></td>
                                    <td><?php echo e($row->durasi); ?></td>
                                    <td>
                                        <?php if($row->status == 1): ?>
                                            <a href="/categories/draft/<?php echo e($row->id); ?>"><span class="badge badge-success">Publish</span></a>
                                        <?php else: ?>
                                            <a href="/categories/publish/<?php echo e($row->id); ?>"><span class="badge badge-danger">Draft</span></a>
                                        <?php endif; ?>
                                    </td>
                                    <td align="center">
                                        <a href="<?php echo e(url('result', $row->id)); ?>">
                                            <span class="btn btn-cyan btn-sm m-1 text-white">Lihat Pengumpulan Ujian Siswa</span>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- template end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.v_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\PROJECT LARAVEL\SIPENTING\resources\views/backend/v_result/index.blade.php ENDPATH**/ ?>