<a href="http://">Beranda</a> |
<a href="{{ route('akun.index') }}">Akun</a> |
<a href="{{ route('type.index') }}">Type</a> |
<a href="{{ route('customer.index') }}">Customer</a>
<p></p>

@yield('content')